#include <iostream>
#include <regex>
#include <iterator>
#include <string>
#include <vector>
#include <cctype>
#include <algorithm>
#include <windows.h>
#include "pila.hpp"
#include "cola.hpp"

using namespace std;
bool evaluarPalindomo(string textoevaluar);
void Palindromo();

int main() {
	int opcion;
    bool R = true;
    
    do {
        cout << "\n DAVID ALEJANDRO ALFARO REALES AR100816" << endl;;
        cout << "\n\n Opciones:" << endl;;
        cout << "\n1. Verificador de palabras palindromos" << endl;
        cout << "\n0. SALIR" << endl;
        
        cout << "\n\nDigite una opcion: ";
        cin >> opcion;
        cout << endl;
        switch (opcion) {
            case 1:
                Palindromo();
                cout << endl;
				break;       
            case 0:
            	R = false;
            	break;
        }        
    } while (R);
	
	return 0;
}

//------------------------------------------------------------------------------------------------------------
bool evaluarPalindomo(string textoevaluar){
	
	char letra;
	string palabraPila;
	string palabraLetra;
	
	Pila<char> pilaLetra;
	Cola<char> colaLetra;
	

	for(int i = 0; i < textoevaluar.length(); i++){
		letra = textoevaluar[i];
		pilaLetra.push(letra);
		colaLetra.enqueue(letra);
	}
	

	for(int i = 0; i < textoevaluar.length(); i++){		
		palabraPila += pilaLetra.pop();
		palabraLetra += colaLetra.dequeue();
	}
		if(palabraPila == palabraLetra){
			cout << "Palabra al reves: " << palabraPila << endl;
			cout << "Palabra al derecho: " << palabraLetra << endl;
		return true;
	}else{
			cout << "Palabra al reves: " << palabraPila << endl;
			cout << "Palabra al derecho: " << palabraLetra << endl;
		return false;
	}
}

void Palindromo(){
	string textooriginal;
	string textoevaluar;
	cout<<"Ingrese la palabra a evaluar: "<< endl;
	cin>> textooriginal;
	
	textoevaluar = textooriginal;
	
	textoevaluar.erase(std::remove(textoevaluar.begin(), textoevaluar.end(), ' '), textoevaluar.end());
	textoevaluar.erase(std::remove_if(textoevaluar.begin(), textoevaluar.end(), [](unsigned char c) { return std::ispunct(c); }), textoevaluar.end()); 
	textoevaluar.erase(std::remove_if(textoevaluar.begin(), textoevaluar.end(), [](unsigned char c) { return std::isdigit(c); }), textoevaluar.end()); 
	transform(textoevaluar.begin(), textoevaluar.end(), textoevaluar.begin(), [](unsigned char c){ return toupper(c); });

 for (int i = 0; i < textoevaluar.length(); i++) {
    
    textoevaluar[i] = toupper(textoevaluar[i]);
  }

	cout << endl;

	if(evaluarPalindomo(textoevaluar)){
		cout << "La palabra ingresada: '" << textoevaluar << "'Es un Palindromo :)" << endl;
	}else{
		cout << "La palabra ingresada: '" << textoevaluar << "' NO es un Palindromo :(" << endl;
	}

}



 



